# قرارگاه مردمی مدافعان وطن — محله کرمان شهر تهران

برنامه‌ی اندروید (WebView + Kotlin) با محتوای مشترک که روی همین مخزن ذخیره می‌شود.

## ساختار
- `app/` — پروژه‌ی اندروید استودیو (`app/src/main/assets/index.html` خودِ برنامه است)
- `data/content.json` — محتوای مشترک (اخبار، مراسمات، گزارش‌ها، اعلان‌ها، پرداخت و…). **ادمین از داخل برنامه آن را به‌روز می‌کند.**
- `media/` — عکس‌هایی که ادمین بارگذاری می‌کند
- `.github/workflows/build-apk.yml` — ساخت خودکار APK

## دریافت APK
هر بار که کدِ برنامه تغییر کند (یا از تب Actions گزینه‌ی *Run workflow*)، APK ساخته می‌شود و در بخش **Releases** مخزن قرار می‌گیرد.

## راه‌اندازی بار اول
1. مخزن باید **Public** باشد (برنامه محتوا را از `raw.githubusercontent.com` می‌خواند).
2. تب Actions ← Build APK ← *Run workflow*؛ بعد از چند دقیقه APK در Releases است.
3. در برنامه: ۵ بار سریع روی لوگوی صفحه‌ی اول ← رمز مدیر (پیش‌فرض `1234`، بلافاصله عوض شود) ← تنظیمات ← «اتصال به گیت‌هاب» و وارد کردن توکن.
   - توکن: GitHub ← Settings ← Developer settings ← Personal access tokens ← Fine-grained tokens ← فقط همین مخزن، دسترسی **Contents: Read and write**.
4. از این پس هرچه ادمین ثبت کند در `data/content.json` و `media/` ذخیره و برای همه منتشر می‌شود.

## اعلان‌ها
برنامه هر ۱۵ دقیقه (و هنگام باز شدن) محتوا را می‌گیرد؛ اعلان تازه و یادآور مراسم (طبق «چند دقیقه قبل») را روی گوشی نشان می‌دهد. (تأخیر معمول ۱۵ تا ۳۰ دقیقه؛ برای اعلان لحظه‌ای باید Firebase اضافه شود.)

## امضای APK (پیشنهادی)
بدون تنظیم، APK با کلید `app/debug.keystore` امضا می‌شود. برای انتشار جدی، یک Keystore بسازید و در Settings ← Secrets مخزن این‌ها را تعریف کنید: `KEYSTORE_B64` (خروجی `base64 release.jks`)، `KEYSTORE_PASSWORD`، `KEY_ALIAS`، `KEY_PASSWORD`.

## ساخت محلی
Android Studio ← Open ← پوشه‌ی مخزن ← Build ← Build APK(s).
