package ir.qarargah.kerman

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Config {
    /** مخزن گیت‌هاب که محتوای برنامه در آن ذخیره می‌شود (باید Public باشد) */
    const val RAW = "https://raw.githubusercontent.com/husseinmilad/appmahalehkerman/main/"
}

/** هر ۱۵ دقیقه محتوای مشترک را از گیت‌هاب می‌گیرد؛ اعلان‌های جدید را نشان می‌دهد و یادآور مراسم را زمان‌بندی می‌کند. */
class PollWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result = try {
        val con = URL(Config.RAW + "data/content.json?t=" + System.currentTimeMillis()).openConnection() as HttpURLConnection
        con.connectTimeout = 15000; con.readTimeout = 15000
        if (con.responseCode != 200) Result.retry()
        else {
            Notifier.processContent(applicationContext, JSONObject(con.inputStream.bufferedReader().readText()))
            Result.success()
        }
    } catch (e: Exception) { Result.retry() }
}
