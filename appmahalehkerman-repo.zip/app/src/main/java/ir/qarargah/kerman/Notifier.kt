package ir.qarargah.kerman

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale

object Notifier {
    private const val CH = "events"

    fun createChannel(c: Context) {
        if (Build.VERSION.SDK_INT >= 26)
            c.getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(CH, "مراسمات", NotificationManager.IMPORTANCE_HIGH))
    }

    fun show(c: Context, title: String, body: String, id: Int) {
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        createChannel(c)
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(c, CH)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title).setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true).setContentIntent(open)
            .setPriority(NotificationCompat.PRIORITY_HIGH).build()
        c.getSystemService(NotificationManager::class.java).notify(id, n)
    }

    private fun pi(c: Context, code: Int, t: String, b: String) = PendingIntent.getBroadcast(
        c, code, Intent(c, ReminderReceiver::class.java).putExtra("t", t).putExtra("b", b).putExtra("c", code),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    /** json: [{id,title,body,at(ms)}] — جایگزین همه‌ی یادآورهای قبلی می‌شود */
    fun schedule(c: Context, json: String) {
        val p = c.getSharedPreferences("rem", Context.MODE_PRIVATE)
        val am = c.getSystemService(AlarmManager::class.java)
        p.getStringSet("ids", emptySet())!!.forEach { am.cancel(pi(c, it.toInt(), "", "")) }
        val ids = HashSet<String>()
        try {
            val a = JSONArray(json)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val at = o.getLong("at")
                if (at <= System.currentTimeMillis()) continue
                val code = o.getString("id").hashCode()
                ids.add(code.toString())
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(c, code, o.getString("title"), o.getString("body")))
            }
        } catch (_: Exception) {}
        p.edit().putStringSet("ids", ids).putString("json", json).apply()
    }

    private fun fa(s: String) = s.map { if (it in '0'..'9') ('\u06F0' + (it - '0')) else it }.joinToString("")

    /** محتوای content.json: اعلان‌های تازه را نشان می‌دهد و یادآور مراسم را زمان‌بندی می‌کند. */
    fun processContent(c: Context, j: JSONObject) {
        val p = c.getSharedPreferences("rem", Context.MODE_PRIVATE)
        val seen = p.getStringSet("seen", null)
        val ann = j.optJSONArray("ann") ?: JSONArray()
        val all = HashSet<String>(seen ?: emptySet())
        for (i in 0 until ann.length()) {
            val o = ann.getJSONObject(i); val id = o.getString("id")
            if (seen != null && !seen.contains(id)) show(c, o.optString("title"), o.optString("body"), id.hashCode())
            all.add(id)
        }
        p.edit().putStringSet("seen", all).apply()
        val ev = j.optJSONArray("events") ?: JSONArray()
        val out = JSONArray()
        val f = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        for (i in 0 until ev.length()) {
            val e = ev.getJSONObject(i)
            val t = e.optString("time").ifEmpty { "00:00" }
            val start = f.parse(e.optString("date") + " " + t)?.time ?: continue
            val lead = e.optString("lead").toLongOrNull() ?: 60L
            val place = e.optString("place")
            out.put(JSONObject().put("id", e.getString("id")).put("title", "یادآوری مراسم: " + e.optString("title"))
                .put("body", "ساعت " + fa(t) + (if (place.isNotEmpty()) " — $place" else ""))
                .put("at", start - lead * 60000))
        }
        schedule(c, out.toString())
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) =
        Notifier.show(c, i.getStringExtra("t") ?: "", i.getStringExtra("b") ?: "", i.getIntExtra("c", 0))
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        c.getSharedPreferences("rem", Context.MODE_PRIVATE).getString("json", null)?.let { Notifier.schedule(c, it) }
    }
}
